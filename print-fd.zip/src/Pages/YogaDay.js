import React, { useState, useEffect } from "react";
import { Card, CardMedia, CardContent, IconButton, Box } from "@mui/material";
import DownloadIcon from "@mui/icons-material/Download";
import WhatsAppIcon from "@mui/icons-material/WhatsApp";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import KeyboardDoubleArrowRightIcon from '@mui/icons-material/KeyboardDoubleArrowRight';
import { Element } from "react-scroll";
import Sidebar from "../component/Sidebar";
import Status from "../assets/ststus advertisment.png";
import html2canvas from 'html2canvas';
import { useLocation } from 'react-router-dom';
// import Button from '@mui/material/Button';
// import GridViewIcon from '@mui/icons-material/GridView';
// import KeyboardDoubleArrowDownIcon from '@mui/icons-material/KeyboardDoubleArrowDown';
import Axios from '../Axios'; // Make sure Axios is properly configured
import { clear } from "@testing-library/user-event/dist/clear";

const YogaDay = () => {
  const [imagesData, setImagesData] = useState([]);
  const [sliderIndex, setSliderIndex] = useState(0);
  const [loading, setLoading] = useState(false);
  const { id } = useLocation().state || {};
  const [error, seterror] = useState();

  const slidesToShow = 3;
  const centerIndex = Math.floor(slidesToShow / 2);

  useEffect(() => {
    const fetchImages = async () => {
      try {
        setLoading(true);
        const response = await Axios.get('event-designs/' + id);
        console.log("API Response:", response.data);
      
      if (response.data.images && response.data.images.length > 0) {
          setImagesData(response.data.images); 
        } 
        else if(response.data.status==='failed'){
          alert("No Datafgfg Found");
          setImagesData([]); 
          const error =()=>{
            seterror(response.data.message);
          }
        }
      else {
          alert("No Data Found");
          console.log("No image data found.");
        }
        setLoading(false);
      } catch (error) {
        console.log("No Data Found",error);
        setLoading(false);
      }
    };

    if (id) {
      fetchImages();
    }
  }, [id]);

  const handleNextSlide = () => {
    if (sliderIndex < imagesData.length - slidesToShow) {
      setSliderIndex(sliderIndex + 1);
    }
  };

  const handlePrevSlide = () => {
    if (sliderIndex > 0) {
      setSliderIndex(sliderIndex - 1);
    }
  };

  const downloadImage = async () => {
    const canvas = await html2canvas(document.getElementById('combined-image'));
    const link = document.createElement('a');
    link.href = canvas.toDataURL('image/png');
    link.download = 'combined-image.png';
    link.click();
  };

  const shareOnWhatsApp = async () => {
    const canvas = await html2canvas(document.getElementById('combined-image'));
    const imageUrl = canvas.toDataURL('image/png');
    const blob = await (await fetch(imageUrl)).blob();
    const url = URL.createObjectURL(blob);

    const message = `Check out this image: ${url}`;
    const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`;

    window.open(whatsappUrl, '_blank');
  };

  return (
    <>
      <Sidebar />
      <style>
        {`
          .yoga-section {
            padding-left: 0px;
            padding-top: -600px;
          }
          @media (min-width: 450px) {
            .yoga-section {
              padding-left: 240px;
            }
          }
        `}
      </style>

      <div className="yoga-section">
        <Element name="yoga-section">
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              padding: 3,
              flexDirection: 'column',
              backgroundColor: '#A6787A',
            }}
          >
            <Box
              sx={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                padding: 2,
              }}
            >
              <IconButton
                onClick={handlePrevSlide}
                disabled={sliderIndex === 0}
                sx={{ fontSize: 30 }}
              >
                <KeyboardDoubleArrowLeftIcon sx={{ fontSize: 60 }} />
              </IconButton>
              <Box
                sx={{
                  display: 'flex',
                  overflow: 'hidden',
                  width: '100%',
                  justifyContent: 'center',
                  gap: 5, // Ensure equal gap between each image
                }}
              >
                {imagesData.slice(sliderIndex, sliderIndex + slidesToShow).map((base64Image, index) => {
                  const isCenter = index === centerIndex;
                  return (
                    <Box key={index}>
                      <Card
                        id={isCenter ? "combined-image" : ""}
                        sx={{
                          marginTop: '80px',
                          position: 'relative',
                          borderRadius: '16px',
                          transition: 'all 0.3s ease-in-out',
                          transform: isCenter ? 'scale(1.1)' : 'scale(1)',
                        }}
                      >
                        <CardMedia
                          component="img"
                          alt="main image"
                          src={`data:image/png;base64,${base64Image}`}
                          title="main image"
                          sx={{
                            width: '200px',
                            height: isCenter ? 400 : 350, // Conditional size based on center
                            objectFit: 'cover',
                            borderRadius: '16px',
                          }}
                        />
                        <CardMedia
                          component="img"
                          alt="status image"
                          image={Status}
                          title="status image"
                          sx={{
                            width: '100%',
                            height: '85%',
                            objectFit: 'contain',
                            position: 'absolute',
                            bottom: -2,
                          }}
                        />
                      </Card>
                      {isCenter && (
                        <CardContent
                          sx={{
                            display: 'flex',
                            justifyContent: 'end',
                            gap: 2,
                            marginTop: 1,
                          }}
                        >
                          <IconButton sx={{ color: '#850000' }} aria-label="download" onClick={downloadImage}>
                            <DownloadIcon />
                          </IconButton>
                          {/* <IconButton sx={{ color: 'green' }} aria-label="share" onClick={shareOnWhatsApp}>
                            <WhatsAppIcon />
                          </IconButton> */}
                        </CardContent>
                      )}
                    </Box>
                  );
                })}
              </Box>
              <IconButton
                onClick={handleNextSlide}
                disabled={sliderIndex >= imagesData.length - slidesToShow}
                sx={{ fontSize: 30 }}
              >
                <KeyboardDoubleArrowRightIcon sx={{ fontSize: 60 }} />
              </IconButton>
            </Box>
            {/* <div style={{ textAlign: "center" }}>
              <Button
                variant="outlined"
                sx={{
                  width: "70%",
                  background: "#fff",
                  borderRadius: "30px",
                }}
                startIcon={<GridViewIcon />}
                endIcon={<KeyboardDoubleArrowDownIcon
                  sx={{
                    textAlign: 'center',
                    alignItems: 'center'
                  }} />}
              > */}
                {/* <Link to='/viewmore' state={id}> */}
                  {/* More Designs */}
                {/* </Link> */}
              {/* </Button> */}
            {/* </div> */}
          </Box>
        </Element>
      </div>
    </>
  );
};

export default YogaDay;